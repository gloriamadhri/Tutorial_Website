<!DOCTYPE html>
<html>
<head>
    
    <title>Document</title>
</head>
<body>
<header class="main">
        <nav>
            <a href="#" class="logo">
                <img src="images/logo1.png"/>
            </a>

            <ul class="menu">
                <li><a href="index.php" class="active">Home</a></li>
                <li><a href="#">Features</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="#">Contact</a></li>
            </ul>
        </nav>
        <div class="main-heading">
            <h1>Create Prespectives With Virtual Reality</h1>
            <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sint provident consectetur ducimus. Blanditiis, culpa!</p>
            <a class="main-btn" href="#">Contact</a>
        </div>
    </header>
        <div class="jumbotron">
  <h1>Eldas</h1>
  <p>we rise by lifting you</p>
</div>
</body>
</html>